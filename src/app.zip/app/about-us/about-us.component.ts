import { Component, OnInit, ElementRef, AfterViewInit } from '@angular/core';

@Component({
  selector: 'app-about-us',
  templateUrl: './about-us.component.html',
  styleUrls: ['./about-us.component.css']
})
export class AboutUsComponent implements OnInit, AfterViewInit {

  constructor(private elementRef: ElementRef) { }

  ngOnInit() {
  }

   ngAfterViewInit(){
         this.elementRef.nativeElement.ownerDocument.body.style.minHeight = "100vh";
         this.elementRef.nativeElement.ownerDocument.body.style.background = "linear-gradient(#fff, #008fb3)";
      }

}
