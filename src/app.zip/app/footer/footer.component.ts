//Importing components for footer page
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.css']
})

//Creating class for footer page
export class FooterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
