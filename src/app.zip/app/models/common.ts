//Common class
export class Common {
      static readonly BASE_API_URL : string = "http://privatebookapi20180329092713.azurewebsites.net/";
      //static readonly BASE_API_URL : string = "http://localhost:2866/";     
}
