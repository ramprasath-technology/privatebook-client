//Diary class
export class Diary {
    date: Date;
    entry: string;
    userId: number;
}

