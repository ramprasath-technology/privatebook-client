export class EventSearchTerms {
    userId: number;
    startDate: Date;
    endDate: Date;
}
