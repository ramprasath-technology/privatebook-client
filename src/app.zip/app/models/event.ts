//Event class
export class Event {
    eventId: number;
    userId: number;
    eventName: string;
    eventDescription: string;
    time: Date;
}
