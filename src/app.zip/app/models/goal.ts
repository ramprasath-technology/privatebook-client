//Goal class
export class Goal {
    goalId: number;
    goalDescription: string;
    isCompleted: boolean;
    userId: number;
    createdDate: Date;
}
