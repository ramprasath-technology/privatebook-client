//Reset password class
export class ResetPassword {
    userId: number;
    newPassword: string;
    securityAnswer: string;
}
