//Sign up class
export class Signup {
    name: string;
    email: string;
    password: string;
    securityQuestion: string;
    securityAnswer: string;
}
