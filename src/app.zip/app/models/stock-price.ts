//Stock price class
export class StockPrice {
    symbol: string;
    currentPrice: number;
    lowPrice: number;
    highPrice: number;
    stockMappingId: number;
}

