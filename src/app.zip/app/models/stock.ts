//Stock class
export class Stock {
    stockMappingId: number;
    userId: number;
    stockSymbol: string;
}
