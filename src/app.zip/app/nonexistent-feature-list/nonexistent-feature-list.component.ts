import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nonexistent-feature-list',
  templateUrl: './nonexistent-feature-list.component.html',
  styleUrls: ['./nonexistent-feature-list.component.css']
})
export class NonexistentFeatureListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
